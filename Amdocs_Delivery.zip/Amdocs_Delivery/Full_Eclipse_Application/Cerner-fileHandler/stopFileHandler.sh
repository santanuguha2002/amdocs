#!/bin/sh
FILE_HANDLER_PID=`jps | grep ApplicationScheduler | grep -v grep | awk '{print " "$1" "}'`

if [ ! -z "$FILE_HANDLER_PID" ]; then
    echo "ApplicationScheduler file handler is going down......"
    kill $FILE_HANDLER_PID  > /dev/null 2>&1
    echo -e "\nShutdown complete for ApplicationScheduler file handler\n"
else
    echo -e "\nApplicationScheduler file handler is not running\n"
fi