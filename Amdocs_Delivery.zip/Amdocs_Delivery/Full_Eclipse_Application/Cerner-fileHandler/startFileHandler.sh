#!/bin/sh

. $HOME/.bash_profile

FILE_HANDLER_PID=`jps | grep ApplicationScheduler | grep -v grep | awk '{print " "$1" "}'`
if [ ! -z "$FILE_HANDLER_PID" ]; 
then
	echo "FileHandler is already running ! "
	exit 0
fi

LPATH="."
echo $LPATH

CLASSPATH=$LPATH/dist/FileHandler.jar:$LPATH/config

export CLASSPATH

FLES=$LPATH/lib/*.jar
for i in $FLES
do	
	CLASSPATH=$CLASSPATH:$i	
done


START_JAVA=$JDK_HOME/jre/bin/java
echo $START_JAVA
MAIN_CLASS_NAME="com.client.adapter.scheduler.ApplicationScheduler" 


if [ -z "$JDK_HOME" ]
then
    echo "JDK_HOME isn't set! The java executable from the current path setting is taken instead."
    START_JAVA=java
fi



# create log directory if not yet present
if [ ! -d "logs" ] ; then
   mkdir logs
fi

# adapt the following to the machine, that is used running the server.
ADD_OPT=${ADD_OPT}"-d64  -Xss1500K -XX:+UseParallelGC -XX:+UseParallelOldGC -XX:NewRatio=2 -XX:ParallelGCThreads=3 "
ADD_OPT=${ADD_OPT}"-d64 -XX:+HeapDumpOnOutOfMemoryError -XX:+PrintGC -XX:+PrintGCDetails -XX:+PrintGCTimeStamps -Xloggc:"$LPATH/logs/${GC_LOG_DESTINATION}.gc

java -Xms512M -Xmx3072M -XX:ErrorFile=${LPATH}/logs/fileHandler_err.log $ADD_OPT -cp $CLASSPATH $MAIN_CLASS_NAME > /dev/null &





