package com.client.adapter.downloader;

import java.io.BufferedOutputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.PrintWriter;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

import org.apache.commons.net.PrintCommandListener;
import org.apache.commons.net.ftp.FTP;
import org.apache.commons.net.ftp.FTPClient;
import org.apache.commons.net.ftp.FTPFile;
import org.apache.commons.net.ftp.FTPReply;
import org.apache.log4j.Logger;

import com.client.adapter.configuration.ApplicationPropertiesCacheHolder;
import com.client.adapter.exception.FTPConnectionException;
import com.client.adapter.exception.FTPDownloaderException;
import com.client.adapter.exception.FTPFileListingException;
import com.client.adapter.exception.PropertiesLoadException;
import com.client.adapter.utility.ApplicationUploadDownloadUtility;

/**
 * {@code FTPAmdocsDownloader} encapsulates all the functionality necessary to
 * retrieve files from an FTP server and download . This class takes care of all
 * low level details of interacting with an FTP server and provides a convenient
 * higher level interface to connect to FTP server.
 * 
 * @author Santanu Guha
 * @since 10-OCT-2019
 * @see FTPClient
 * @version 1.0
 */
public class FTPDownloader {

	private static final Logger LOGGER = Logger.getLogger(FTPDownloader.class.getName());

	private FTPClient ftp = null;
	private static int BUFFERSIZE = 8192;
	private ApplicationPropertiesCacheHolder propertiesCache = null;
	private Set<String> allowableFileExts = null;
	private String defaultExt = "txt";
	private String client;

	public FTPDownloader(String host, String user, String pwd)
			throws FTPConnectionException, IOException, PropertiesLoadException {
		this.ftp = new FTPClient();
		this.ftp.addProtocolCommandListener(new PrintCommandListener(new PrintWriter(System.out)));
		/**
		 * There are some issues regarding buffering in existing FTPClient so
		 * setting buffer size explicitly
		 */
		this.ftp.setBufferSize(BUFFERSIZE);

		int reply;
		this.ftp.connect(host);
		/**
		 * This method checks the connection to the FTP server to check that the
		 * connection was successful since connect is of type void
		 **/
		reply = ftp.getReplyCode();
		if (!FTPReply.isPositiveCompletion(reply)) {
			ftp.disconnect();
			throw new FTPConnectionException("Exception in connecting to FTP Server");
		}
		ftp.login(user, pwd);
		ftp.setFileType(FTP.BINARY_FILE_TYPE);
		/**
		 * Set the current data connection mode to
		 * PASSIVE_LOCAL_DATA_CONNECTION_MODE . Use thismethod only for data
		 * transfers between the client and server.This method causes a PASV (or
		 * EPSV) command to be issued to the serverbefore the opening of every
		 * data connection, telling the server toopen a data port to which the
		 * client will connect to conductdata transfers. The FTPClient will stay
		 * in PASSIVE_LOCAL_DATA_CONNECTION_MODE until themode is changed by
		 * calling some other method
		 */
		ftp.enterLocalPassiveMode();

		this.propertiesCache = ApplicationPropertiesCacheHolder.getInstance();
		this.allowableFileExts = ApplicationUploadDownloadUtility.getAllowableFileExtensionList(
				this.propertiesCache.getProperty("TARGET_FILE_EXTENSIONS"), this.defaultExt);
		this.client = this.propertiesCache.getProperty("CLIENT_NAME");
	}

	/**
	 * This method download the FTP file from FTP server
	 * 
	 * @throws FTPDownloaderException
	 *
	 * @since 10-OCT-2019
	 * @see FTPClient
	 * @see BufferedOutputStream
	 */
	public Boolean downloadFile(FTPFile ftpFile) throws FTPDownloaderException {
		boolean successOrFail = Boolean.FALSE;
		InputStream inputStream = null;
		OutputStream outputStream = null;
		try {

			String userHome = ApplicationUploadDownloadUtility.getUserHomeDirectory();
			Path path = Paths.get(userHome, this.getClient(), getOperation());
			ApplicationUploadDownloadUtility.ensureDirectories(path.toString());
			Path downloadLocalFile = Paths.get(path.toString(), ftpFile.getName());
			if (Files.notExists(downloadLocalFile))
				Files.createFile(downloadLocalFile);

			outputStream = new BufferedOutputStream(
					new FileOutputStream(downloadLocalFile.toAbsolutePath().toString()));

			inputStream = this.ftp.retrieveFileStream(ftpFile.getName());
			int available = inputStream.available();
			LOGGER.info("Available bytes to read : " + available);
			
			int bufferSize = Integer.parseInt(ApplicationPropertiesCacheHolder.getInstance().getProperty("DOWNLOAD_BUFFER_SIZE"));
			
			LOGGER.info("Download Buffer size configured in application.properties: "+bufferSize);
			
			byte[] chunkBytesArray = new byte[bufferSize];
			int bytesRead = -1;
			while ((bytesRead = inputStream.read(chunkBytesArray)) != -1) {
				outputStream.write(chunkBytesArray, 0, bytesRead);

			}
			successOrFail = this.ftp.completePendingCommand();

			if (successOrFail) {
				LOGGER.info("File [" + ftpFile.toString() + "] has been downloaded successfully....");
			}

		} catch (IOException ex) {
			LOGGER.error("Error: " + ex.getMessage());
			throw new FTPDownloaderException(ex.getMessage());
		} catch (Exception e) {
			LOGGER.error("Error: " + e.getMessage());
			throw new FTPDownloaderException(e.getMessage());
		} finally {
			try {
				if (outputStream != null)
					outputStream.close();
				if (inputStream != null)
					inputStream.close();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}

		return successOrFail;
	}

	/**
	 * This method returns the target files to download depending on the allowed
	 * file extensions mentioned in application.properties with a key as
	 * TARGET_FILE_EXTENSIONS. Always the txt file(s) are by default eligible to
	 * be selected
	 * 
	 * @return <code>List<FTPFile></code>
	 * @throws <code>FTPFileListingException</code>
	 * @since 11-OCT-2019
	 * @see com.client.adapter.utility.ApplicationUploadDownloadUtility for
	 *      findExtension(String fileName)
	 * @see Arrays
	 * @see <code>FTPFileListingException</code>
	 * @see getAllowableFileExts() method
	 */
	public List<FTPFile> getFileListByExtension() throws FTPFileListingException {
		LOGGER.debug("getFileListByExtension() method started executing ...");
		FTPFile[] fileList = null;
		List<FTPFile> txtFiles = new ArrayList<FTPFile>(5);
		try {
			fileList = this.ftp.listFiles();
			txtFiles = Arrays.stream(fileList)
					.filter((s) -> getAllowableFileExts()
							.contains(ApplicationUploadDownloadUtility.findExtension(s.getName()).orElse("")))
					.collect(Collectors.toList());

			LOGGER.info("Size : " + txtFiles.size());
		} catch (Exception e) {
			throw new FTPFileListingException("Exception occurred during listing FTP server files");
		}
		LOGGER.debug("getFileListByExtension() method completed executing ...");
		return txtFiles;
	}

	/**
	 * Closes the connection to the FTP server and restores connection
	 * parameters to the default values.
	 * 
	 * Logout of the FTP server by sending the QUIT command.
	 *
	 * @return True if successfully completed, false if not.
	 *
	 * @throws IOException
	 *             If an error occurs while disconnecting.
	 */
	public boolean disconnect() {
		boolean isDisconnected = Boolean.FALSE;
		if (this.ftp.isConnected()) {
			try {
				isDisconnected = this.ftp.logout();
				LOGGER.info(isDisconnected == true ? "The FTP connection is disconnected successfully ..." : "");
				this.ftp.disconnect();
			} catch (IOException f) {
				LOGGER.error("disconnection attempt failed", f);
			}
		}
		
		return isDisconnected;
	}

	/**
	 * 
	 * @param files
	 */
	public void printAllFiles(List<FTPFile> files) {
		LOGGER.info("Printing all files ......");
		files.stream().forEach(p -> LOGGER.info(p.toString()));
	}

	public void downloadAllFiles(List<FTPFile> files) {
		LOGGER.debug("Downloading all files ......");
		for (FTPFile file : files) {
			LOGGER.info("File download started .....");
			try {
				this.downloadFile(file);
			} catch (FTPDownloaderException e) {
				LOGGER.error("File [" + file.getName() + " ] download failed ...");
				LOGGER.error(e);
			}
			LOGGER.debug("File Download completed .....");
		}
	}
	
	/**
     * Change the current working directory using current FTP session.
     *
     * @param pathname  The new current working directory.
     * @return True if successfully completed, false if not.
     * @throws IOException
    
     * @throws IOException  If an I/O error occurs while either sending a
     *      command to the server or receiving a reply from the server.
     */
	public boolean changeWorkingDirectory(String pathname) throws IOException{
		// Changes working directory
        boolean status = this.ftp.changeWorkingDirectory(pathname);
        showServerReply(this.ftp);

        if (status) {
            LOGGER.info("Successfully changed working directory.");
        } else {
        	LOGGER.info("Failed to change working directory. See server's reply.");
        }
        
        return status;
	}
	
	/**
	 * 
	 * @param ftpClient The FTP client object 
	 */
	
	private void showServerReply(FTPClient ftpClient) {
        String[] replies = ftpClient.getReplyStrings();
        if (replies != null && replies.length > 0) {
            for (String aReply : replies) {
                LOGGER.info("SERVER: " + aReply);
            }
        }
    }

	public FTPClient getFtp() {
		return ftp;
	}
	
	public ApplicationPropertiesCacheHolder getPropertiesCache() {
		return propertiesCache;
	}

	public Set<String> getAllowableFileExts() {
		return allowableFileExts;
	}

	public String getClient() {
		return client;
	}
	
	public String getOperation(){
		return "DOWNLOAD";
	}

	public static void main(String[] args) throws FTPFileListingException {
		
		 /**String server = "ftp.dlptest.com"; 
		 String user ="dlpuser@dlptest.com";
		 String pass = "fLDScD4Ynth0p4OJ6bW6qCxjh";
		 **/
		 
		/*String server = "speedtest4.tele2.net";
		// int port = 21;
		String user = "anonymous";
		String pass = "anonymous";*/
		
		 String server = "demo.wftpserver.com"; 
		 String user ="demo-user";
		 String pass = "demo-user";	

		FTPDownloader downloader = null;
		
		try {
			String client = ApplicationPropertiesCacheHolder.getInstance().getProperty("CLIENT_NAME");
			downloader = new FTPDownloader(server, user, pass);
			//downloader.changeWorkingDirectory("/download");
		} catch (Exception e) {
			e.printStackTrace();
		}

		List<FTPFile> ftpFileList = downloader.getFileListByExtension();

		downloader.printAllFiles(ftpFileList);

		// downloader.downloadAllFiles(ftpFileList);

		downloader.disconnect();

	}
}
