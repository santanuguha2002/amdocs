/**
 * 
 */
package com.client.adapter.exception;

/**
 * The class {@code FTPConnectionException} and its subclasses are a form of
 * {@code Exception} that indicates conditions like Failed attempt to connect FTP
 *  that a reasonable application might want to catch. 
 *  
 * @author Santanu Guha
 * @since 09-OCT-2019
 * @see Exception
 *
 */
public class FTPConnectionException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = -531488704905459674L;	

	/**
	 * @param message
	 */
	public FTPConnectionException(String message) {
		super(message);		
	}

	/**
	 * @param cause
	 */
	public FTPConnectionException(Throwable cause) {
		super(cause);
		// TODO Auto-generated constructor stub
	}

	/**
	 * @param message
	 * @param cause
	 */
	public FTPConnectionException(String message, Throwable cause) {
		super(message, cause);		
	}

	

}
