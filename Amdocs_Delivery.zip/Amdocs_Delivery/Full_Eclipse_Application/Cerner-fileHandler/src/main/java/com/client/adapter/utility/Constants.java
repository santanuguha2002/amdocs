package com.client.adapter.utility;

public final class Constants {

	public static final String _FTP_PROPERTIES = "/ftp.properties";
    public static final String _APP_PROPERTIES = "/application.properties";	
    
    public static final String HOST = "host";
	public static final String USER = "user";
	public static final String PASS = "pass";
	public static final String TARGET_UPLOAD_DIRECTORY = "TARGET_UPLOAD_DIRECTORY";
	public static final String TARGET_DOWNLOAD_DIRECTORY = "TARGET_DOWNLOAD_DIRECTORY";

}
