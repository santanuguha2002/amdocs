package com.client.adapter.utility;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Enumeration;
import java.util.HashSet;
import java.util.List;
import java.util.Optional;
import java.util.Properties;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.log4j.Logger;

/**
 * Utility class for some methods which is useful for File Handler project
 * @author Santanu
 * @since 11-OCT-2019
 * @see System
 * @see Path
 *
 */
public final class ApplicationUploadDownloadUtility {

	private static final Logger LOGGER = Logger.getLogger(ApplicationUploadDownloadUtility.class.getName());

	/**
	 * 
	 * @return
	 */
	public static String getUserHomeDirectory() {
		String home = System.getProperty("user.home");
		return home;
	}
	
	public static String getUserTempDirectory() {
		String tempDir = System.getProperty("java.io.tmpdir");
		return tempDir;
	}

	/**
	 * 
	 * @param absPath
	 * @return
	 */
	public static Path ensureDirectories(final String absPath) {
		Path path = null;
		try {
			path = Paths.get(absPath);
			if (!Files.exists(path)){
				path = Files.createDirectories(path);
				LOGGER.info("Directory Created successfully at [ "+path.toAbsolutePath().toString()+" ]");
			}else{
				LOGGER.info("Download to directory already exists at [ "+path.toAbsolutePath().toString()+" ]");
			}
				
		} catch (Exception e) {
			LOGGER.error("Directory creation failed ");
		}
		return path;
	}

	/**
	 * Copy a set of properties from one Property to another.
	 * <p>
	 *
	 * @param srcProp
	 *            Source set of properties to copy from.
	 * @param destProp
	 *            Dest Properties to copy into.
	 *
	 **/
	public static void copyProperties(Properties destProp, final Properties srcProp) {
		Enumeration<?> propertyNames = srcProp.propertyNames();

		while (propertyNames.hasMoreElements()) {
			Object key = propertyNames.nextElement();
			destProp.put(key, srcProp.get(key));

		}
	}

	/**
	 * Convert extensions separated by pipe ("|") and returns {@link List} of
	 * {@link String}
	 * <p>
	 * This method also provides a checking that only if String contains only
	 * Alphabets using Regular Expression The default extension element of this
	 * set can be passed as <code>defaultExt</code> parameter. If there is no
	 * other extension is found then defaultExt value will set as the only
	 * element in Set
	 * </p>
	 * 
	 * @param extensions
	 *            {@link String}
	 * @param defaultExt
	 *            {@link String}
	 * @return {@link Set}
	 */
	public static Set<String> getAllowableFileExtensionList(String extensions, String defaultExt) {
		Set<String> set = new HashSet<String>(4);
		if (extensions != null && !("".equals(extensions))) {
			String[] extArray = extensions.split("\\|");
			for (String element : extArray) {
				LOGGER.info("Element : " + element);
				if (element != null && !"".equals(element) && element.trim().matches("^[a-zA-Z]*$")) {
					set.add(element);
				}
			}
		}

		if (set.isEmpty() || (defaultExt != null && !"".equals(defaultExt)))
			set.add(defaultExt);
		return set;
	}

	/**
	 * 
	 * @param fileName
	 * @return
	 */
	public static Optional<String> findExtension(String fileName) {
		int lastIndex = fileName.lastIndexOf('.');
		if (lastIndex == -1) {
			return Optional.empty();
		}
		return Optional.of(fileName.substring(lastIndex + 1));
	}

	/**
	 * This method renames file extension with the supplied new extension .
	 * 
	 * @author Santanu
	 * @since 12/10/2019
	 * @param source
	 *            The source file name
	 * @param newExtension
	 * @return {@link String}
	 */
	public static String renameFileExtension(String source, String newExtension) {

		LOGGER.debug("Entering into ApplicationUploadDownloadUtility : renameFileExtension");
		String target;
		final String currentExtension = findExtension(source).orElse("");

		if (currentExtension.equals("")) {
			target = source + "." + newExtension;
		} else {
			target = source.replaceFirst(Pattern.quote("." + currentExtension) + "$",
					Matcher.quoteReplacement("." + newExtension));

		}

		LOGGER.debug("Exiting into ApplicationUploadDownloadUtility : renameFileExtension");

		return target;
	}
	
	/**
	 * This method is to rename 
	 * @param inputFile
	 * @param outdir The out put directory
	 * @param ext The extension of the which is going to be renamed . 
	 * @return {@link Boolean}
	 * @throws IOException
	 */
	public static boolean renameFile(File outdir , String fileName, String ext)  throws IOException{
		
		LOGGER.debug("Entering into ApplicationUploadDownloadUtility : renameFile");
		
		final File outPutFile = new File(outdir.getCanonicalPath().concat(File.separator).concat(fileName));
		
		final String sourceCanonical = new StringBuffer(outdir.getCanonicalPath().concat(File.separator).concat(fileName)).toString();
		
		String targetCanonical = renameFileExtension(sourceCanonical, ext);
		
		final File _rjFile = new File(targetCanonical);	
		
		LOGGER.info("Source Path : "+sourceCanonical);
		LOGGER.info("Target Path : "+targetCanonical);
		
		LOGGER.debug("Exiting from ApplicationUploadDownloadUtility : renameFile");
		
		return outPutFile.renameTo(_rjFile);
		
		
		
	}

	public static void moveFile(File source, File dest) throws IOException {
		LOGGER.info("Moving file from [ " + source.getAbsolutePath() + " ] to [ " + dest.getAbsolutePath() + " ]");
		InputStream inStream = null;
		OutputStream outStream = null;

		try {
			inStream = new FileInputStream(source);
			outStream = new FileOutputStream(dest);

			byte[] buffer = new byte[8192];

			int length;
			// copy the file content in bytes
			while ((length = inStream.read(buffer)) > 0) {
				outStream.write(buffer, 0, length);
			}

			inStream.close();
			outStream.close();

			LOGGER.info("Moved file successfully ...");

			// delete the original file
			source.delete();

			LOGGER.info("Deleted file[ " + source.getAbsolutePath() + " ] from source location");
		} catch (IOException e) {
			throw new IOException("Error while File performing Move operation,", e);
		} catch (Exception e) {
			throw new IOException("Error while File performing Move operation,", e);
		}
	}

	public static void main(String args[]) throws IOException {
		/*String extensions = "txt|zip|ser";
		Set<String> list = ApplicationUploadDownloadUtility.getAllowableFileExtensionList(extensions, "pdf");
		System.out.println("List : " + list);

		String fileName = "Santanu.zip";
		Optional<String> result = findExtension(fileName);
		System.out.println("Optional Value : " + result.orElse(""));
		
		String what = renameFileExtension("Santanu.txt", "pdf");
		System.out.println("What : "+what);*/
		
		String home = ApplicationUploadDownloadUtility.getUserHomeDirectory();
		System.out.println("Home : "+home);
		
		File file = new File(home+System.getProperty("file.separator")+"file.txt");
		boolean result = file.createNewFile();
		System.out.println("result : "+result);
        try {
			if(result){
				System.out.println("Location of File : "+file.getAbsolutePath());
				 
				File newFile = new File(Paths.get(ApplicationUploadDownloadUtility.getUserTempDirectory(), file.getName()).toAbsolutePath().toString());
				ApplicationUploadDownloadUtility.moveFile(file, newFile);
				System.out.println("Moved ...");
			}
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}
