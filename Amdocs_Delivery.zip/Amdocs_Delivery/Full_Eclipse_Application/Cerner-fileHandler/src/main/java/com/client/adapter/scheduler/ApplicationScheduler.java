package com.client.adapter.scheduler;

import java.util.Date;

import org.apache.log4j.Logger;
import org.quartz.CronScheduleBuilder;
import org.quartz.JobBuilder;
import org.quartz.JobDetail;
import org.quartz.Scheduler;
import org.quartz.Trigger;
import org.quartz.TriggerBuilder;
import org.quartz.impl.StdSchedulerFactory;

import com.client.adapter.configuration.ApplicationPropertiesCacheHolder;
import com.client.adapter.exception.PropertiesLoadException;
import com.client.adapter.jobs.DownloaderJob;
import com.client.adapter.jobs.UploaderJob;
import com.client.adapter.utility.Constants;

/**
 * This class is to schedule download & upload scheduler 
 * 
 * @author santanu guha 
 * @since 14-10-2019
 * @version 1.0
 * @see  {@link Scheduler}
 * @see JobDetail
 * @see Trigger
 *
 */
public class ApplicationScheduler {

	private static final Logger LOGGER = Logger.getLogger(ApplicationScheduler.class.getName());

	private ApplicationPropertiesCacheHolder propertiesCache = null;

	public ApplicationScheduler() throws PropertiesLoadException {
		super();
		this.propertiesCache = ApplicationPropertiesCacheHolder.getInstance();
	}
	
	/**
	 * 
	 * @return
	 */
	public ApplicationPropertiesCacheHolder getPropertiesCache() {
		return propertiesCache;
	}
	
	/**
	 * 
	 * @return
	 */
	public Date scheduleDownloaderJob() {
		Date jobStartDate = null;
		try {
			JobDetail downloadJobDetail = JobBuilder.newJob(DownloaderJob.class)
					.withIdentity("downloadJobDetail", "group1").build();
			downloadJobDetail.getJobDataMap().put(Constants.HOST, propertiesCache.getProperty("server"));
			downloadJobDetail.getJobDataMap().put(Constants.USER, propertiesCache.getProperty("user"));
			downloadJobDetail.getJobDataMap().put(Constants.PASS, propertiesCache.getProperty("password"));
			downloadJobDetail.getJobDataMap().put(Constants.TARGET_DOWNLOAD_DIRECTORY,	propertiesCache.getProperty("TARGET_UPLOAD_DIRECTORY"));

			Trigger trigger1 = TriggerBuilder.newTrigger().withIdentity("cronTrigger1", "group1")
					.withSchedule(CronScheduleBuilder.cronSchedule(propertiesCache.getProperty("DOWNLOAD_CRON_PATTERN")))
					.build();

			Scheduler scheduler1 = new StdSchedulerFactory().getScheduler();
			scheduler1.start();
			jobStartDate = scheduler1.scheduleJob(downloadJobDetail, trigger1);
			System.out.println("Download Job triggered ...." + jobStartDate.toLocaleString());

		} catch (Exception e) {
			LOGGER.error(e);
			e.printStackTrace();
		}

		return jobStartDate;
	}

	/**
	 * 
	 * @return
	 */
	public Date scheduleUploaderJob() {
		Date jobStartDate = null;
		try {
			JobDetail uploadJobDetail = JobBuilder.newJob(UploaderJob.class).withIdentity("uploadJobDetail", "group2")
					.build();
			uploadJobDetail.getJobDataMap().put(Constants.HOST, propertiesCache.getProperty("server"));
			uploadJobDetail.getJobDataMap().put(Constants.USER, propertiesCache.getProperty("user"));
			uploadJobDetail.getJobDataMap().put(Constants.PASS, propertiesCache.getProperty("password"));
			uploadJobDetail.getJobDataMap().put(Constants.TARGET_UPLOAD_DIRECTORY,
					propertiesCache.getProperty("TARGET_UPLOAD_DIRECTORY"));

			Trigger trigger2 = TriggerBuilder.newTrigger().withIdentity("cronTrigger2", "group2")
					.withSchedule(CronScheduleBuilder.cronSchedule(propertiesCache.getProperty("UPLOAD_CRON_PATTERN")))
					.build();

			Scheduler scheduler2 = new StdSchedulerFactory().getScheduler();
			scheduler2.start();
			jobStartDate = scheduler2.scheduleJob(uploadJobDetail, trigger2);
			System.out.println("Upload Job triggered ...." + jobStartDate.toLocaleString());

		} catch (Exception e) {
			LOGGER.error(e);
		}

		return jobStartDate;
	}
	
	/**
	 * 
	 * @return
	 */
	private boolean isDownloaderJobRunnable() {
		boolean defaultStatus = false;
		try{
			String status = this.getPropertiesCache().getProperty("TURN_ON_DOWNLOAD_SCHEDULER");
			System.out.println("TURN_ON_DOWNLOAD_SCHEDULER key is set as : "+status);
			
			if (status != null && "ON".equalsIgnoreCase(status.trim())){
				defaultStatus = true;
				LOGGER.info("Downloader job is set as \" ON \" ");
			}
		}catch (Exception e) {
			LOGGER.error("There is some issue in configuring TURN_ON_DOWNLOAD_SCHEDULER property in application.properties . The default download scheduler is set to OFF ");			
		}
		
		return defaultStatus;
	}
	
	/**
	 * 
	 * @return
	 */
	private boolean isUploaderJobRunnable() {
		
		boolean defaultStatus = false;
		try{

		String status = this.getPropertiesCache().getProperty("TURN_ON_UPLOAD_SCHEDULER");
		System.out.println("TURN_ON_UPLOAD_SCHEDULER  key is set as : "+status);
		
		if (status != null && "ON".equalsIgnoreCase(status.trim())){
			defaultStatus = true;
			LOGGER.info("Uploader job is set as \" ON \" ");
		}
		
		}catch (Exception e) {
			LOGGER.error("There is some issue in configuring TURN_ON_UPLOAD_SCHEDULER property in application.properties . The default upload scheduler is set to OFF ");
		}
		return defaultStatus;
	}
	
	public static void main(String args[]) {
		
		LOGGER.info("@@@@@@@@@@@@@@@@@@@@@@@@ Application scheduler is starting @@@@@@@@@@@@@@@@@@@@@");

		ApplicationScheduler scheduler = null;
		try {

			scheduler = new ApplicationScheduler();

			if (scheduler.isDownloaderJobRunnable() == true){
				scheduler.scheduleDownloaderJob();
			}

			if (scheduler.isUploaderJobRunnable() == true )
				scheduler.scheduleUploaderJob();

		} catch (PropertiesLoadException e) {

			LOGGER.error("Exception occurred during scheduling jobs ....");
			LOGGER.error("The system is going to exit ...");
			System.exit(1);

		} catch (Exception e) {

			LOGGER.error("Exception occurred during scheduling jobs ....");
			LOGGER.error("The system is going to exit ...");
			System.exit(1);
		}

	}

}