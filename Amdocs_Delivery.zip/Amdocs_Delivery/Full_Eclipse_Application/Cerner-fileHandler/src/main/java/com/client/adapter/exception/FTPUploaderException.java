package com.client.adapter.exception;

public class FTPUploaderException extends Exception {

	public FTPUploaderException(String message) {
		super(message);		
	}

	public FTPUploaderException(Throwable cause) {
		super(cause);		
	}

	public FTPUploaderException(String message, Throwable cause) {
		super(message, cause);		
	}

}
