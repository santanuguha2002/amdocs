package com.client.adapter.exception;

public class BackupFileException extends Exception {
	
	public BackupFileException(String message) {
		super(message);
		
	}

	public BackupFileException(Throwable cause) {
		super(cause);
		
	}

	public BackupFileException(String message, Throwable cause) {
		super(message, cause);
		
	}

	
}
