package com.client.adapter.configuration;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.Properties;
import java.util.Set;

import org.apache.log4j.Logger;

import com.client.adapter.exception.PropertiesLoadException;
import com.client.adapter.utility.ApplicationUploadDownloadUtility;
import com.client.adapter.utility.Constants;
/**
 * The {@code ApplicationPropertiesCacheHolder} class represents a persistent set of
 * properties mentioned in different application specific properties file . 
 * Each key and its corresponding value in
 * the property list is a string. 
 * 
 * <p>This class is thread-safe: multiple threads can share a single
 * <tt>Properties</tt> object without the need for external synchronization.

 *
 * @author  Santanu Guha
 * @since   10-OCT-2019
 */
public final class ApplicationPropertiesCacheHolder implements Cloneable{	

	private static final Logger _LOGGER = Logger.getLogger(ApplicationPropertiesCacheHolder.class.getName());
	
	private static volatile ApplicationPropertiesCacheHolder propertiesCache = null;	
	private static final Properties PROPERTIES = new Properties();
	
	private ApplicationPropertiesCacheHolder() throws PropertiesLoadException {
		_LOGGER.info(getClass().getSimpleName()+" object is created ...");
		loadProperties();
	}
	
	public static ApplicationPropertiesCacheHolder getInstance() throws PropertiesLoadException {
		ApplicationPropertiesCacheHolder result = propertiesCache;
		if (result == null) {
			synchronized (ApplicationPropertiesCacheHolder.class) {
				result = propertiesCache;
				if (result == null)
					propertiesCache = result = new ApplicationPropertiesCacheHolder();
			}
		}
		return result;
	}
	
	/**
    * Get common properties object 
    * 
    * @author Santanu
    * @since 10/10/2019  
    * @return {@link String}
    * @see Properties
    */
	private  Properties getApplicationProperties(){
	        return ApplicationPropertiesCacheHolder.PROPERTIES;
	}  
	
	/**
    * Get property value by providing <tt>String</tt> key .
    * 
    * @author Santanu
    * @since 10/10/2019 
    * @param key to search value
    * @return {@link String}
    * @see Properties
    */
   public String getProperty(String key){
      return getApplicationProperties().getProperty(key);
   }
	    
   /**
     * @author Santanu
     * @since 10/10/2019 
     * <p>
     *  
     * Returns a set of keys in this property list where
     * the key and its corresponding value are strings,
     * including distinct keys in the default property list if a key
     * of the same name has not already been found from the main
     * properties list.  Properties whose key or value is not
     * of type <tt>String</tt> are omitted.
     * <p>
     * The returned set is not backed by the <tt>Properties</tt> object.
     * Changes to this <tt>Properties</tt> are not reflected in the set,
     * or vice versa.
     * 
    * @param key to search value
    * @return {@link Set}
    * @see Properties
    */
   public Set<String> getAllPropertyNames(){
      return getApplicationProperties().stringPropertyNames();
   }
	   
   /**
    * Tests if the specified object is a key in this hashtable.
    *
    * @param   key   possible key
    * @return  <code>true</code> if and only if the specified object
    *          is a key in this hashtable, as determined by the
    *          <tt>equals</tt> method; <code>false</code> otherwise.
    * @throws  NullPointerException  if the key is <code>null</code>
    * @see     #contains(Object)
    */
   public boolean containsKey(String key){
      return getApplicationProperties().containsKey(key);
   } 
   
   /**
    * Loads different property files and merges those into a common property object
    * 
    * @author Santanu
 * @throws PropertiesLoadException 
    * @since 10/10/2019    * 
    * @see Properties
    */	
   private void loadProperties() throws PropertiesLoadException {

		InputStream ftpStream = null;
		InputStream appStream = null;
		Properties p = null;
		try {

			ftpStream = ApplicationPropertiesCacheHolder.class.getResourceAsStream(Constants._FTP_PROPERTIES);
			appStream = ApplicationPropertiesCacheHolder.class.getResourceAsStream(Constants._APP_PROPERTIES);

			if (ftpStream != null && appStream != null) {
				p = new Properties();
				try {
					p.load(ftpStream);
					ApplicationUploadDownloadUtility.copyProperties(PROPERTIES, p);
					p.load(appStream);
					ApplicationUploadDownloadUtility.copyProperties(PROPERTIES, p);

				} catch (IOException e) {
					System.out.println("Error: Properties loading failed ");
					System.exit(1);
				} finally {
					try {
						if (ftpStream != null)
							ftpStream.close();
						if (appStream != null)
							appStream.close();
					} catch (IOException e) {
						// Ignored
					}
				}
			} else {				
				System.out.println("Error: Properties loading failed ");
				System.exit(1);
			}
		} catch (Exception e) {
			_LOGGER.error("Properties load failed ....");
			throw new PropertiesLoadException("Property files loading failed");
		}

	}
	
	@Override
	protected Object clone() throws CloneNotSupportedException {
		
		return new CloneNotSupportedException("Clone is not supported for ApplicationPropertiesCacheHolder class");
	}

}
