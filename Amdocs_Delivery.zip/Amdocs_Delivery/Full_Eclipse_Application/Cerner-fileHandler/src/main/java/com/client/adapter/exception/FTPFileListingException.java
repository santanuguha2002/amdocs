package com.client.adapter.exception;

public class FTPFileListingException extends FTPDownloaderException {

	public FTPFileListingException(String message) {
		super(message);		
	}

	public FTPFileListingException(Throwable cause) {
		super(cause);		
	}

	public FTPFileListingException(String message, Throwable cause) {
		super(message, cause);		
	}

}
