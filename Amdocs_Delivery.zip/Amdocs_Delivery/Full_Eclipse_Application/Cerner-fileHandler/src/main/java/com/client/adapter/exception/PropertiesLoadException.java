package com.client.adapter.exception;

public class PropertiesLoadException extends Exception {

	private static final long serialVersionUID = -274795577242887169L;

	public PropertiesLoadException() {
		
	}

	public PropertiesLoadException(String message) {
		super(message);
		
	}

	public PropertiesLoadException(Throwable cause) {
		super(cause);
		
	}

	public PropertiesLoadException(String message, Throwable cause) {
		super(message, cause);
		
	}

	public PropertiesLoadException(String message, Throwable cause, boolean enableSuppression,
			boolean writableStackTrace) {
		super(message, cause, enableSuppression, writableStackTrace);
		
	}

}
