package com.client.adapter.uploader;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.io.PrintWriter;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import org.apache.commons.net.PrintCommandListener;
import org.apache.commons.net.ftp.FTP;
import org.apache.commons.net.ftp.FTPClient;
import org.apache.commons.net.ftp.FTPReply;
import org.apache.log4j.Logger;

import com.client.adapter.configuration.ApplicationPropertiesCacheHolder;
import com.client.adapter.exception.BackupFileException;
import com.client.adapter.exception.FTPConnectionException;
import com.client.adapter.exception.FTPDownloaderException;
import com.client.adapter.exception.FTPFileListingException;
import com.client.adapter.exception.FTPUploaderException;
import com.client.adapter.exception.PropertiesLoadException;
import com.client.adapter.utility.ApplicationUploadDownloadUtility;

/**
 * {@code FTPUploader} encapsulates all the functionality necessary to retrieve
 * files from an FTP server and download . This class takes care of all low
 * level details of interacting with an FTP server and provides a convenient
 * higher level interface to connect to FTP server.
 * 
 * @author Santanu Guha
 * @since 10-OCT-2019
 * @see FTPClient
 * @version 1.0
 */
public final class FTPUploader {

	private static final Logger LOGGER = Logger.getLogger(FTPUploader.class.getName());

	private FTPClient ftp = null;
	private static final int BUFFERSIZE = 8192;
	private ApplicationPropertiesCacheHolder propertiesCache = null;
	private Set<String> allowableFileExts = null;
	private String defaultExt = "txt";
	private String client;
	private List<String> successfulUploadList = null;
	private List<String> failedUploadList = null;
	private int totalFileCount=0;
	private String inputDirPath;
	private Path backupPath;

	public FTPUploader(String host, String user, String pwd)
			throws FTPConnectionException, IOException, PropertiesLoadException {
		this.ftp = new FTPClient();
		this.ftp.addProtocolCommandListener(new PrintCommandListener(new PrintWriter(System.out)));
		/**
		 * There are some issues regarding buffering in existing FTPClient so
		 * setting buffer size explicitly
		 */
		this.ftp.setBufferSize(BUFFERSIZE);

		int reply;
		this.ftp.connect(host);
		/**
		 * This method checks the connection to the FTP server to check that the
		 * connection was successful since connect is of type void
		 **/
		reply = ftp.getReplyCode();
		if (!FTPReply.isPositiveCompletion(reply)) {
			ftp.disconnect();
			throw new FTPConnectionException("Exception in connecting to FTP Server");
		}
		ftp.login(user, pwd);
		ftp.setFileType(FTP.BINARY_FILE_TYPE);
		/**
		 * Set the current data connection mode to
		 * PASSIVE_LOCAL_DATA_CONNECTION_MODE . Use thismethod only for data
		 * transfers between the client and server.This method causes a PASV (or
		 * EPSV) command to be issued to the serverbefore the opening of every
		 * data connection, telling the server toopen a data port to which the
		 * client will connect to conductdata transfers. The FTPClient will stay
		 * in PASSIVE_LOCAL_DATA_CONNECTION_MODE until themode is changed by
		 * calling some other method
		 */
		ftp.enterLocalPassiveMode();

		this.propertiesCache = ApplicationPropertiesCacheHolder.getInstance();
		this.allowableFileExts = ApplicationUploadDownloadUtility.getAllowableFileExtensionList(
				this.propertiesCache.getProperty("TARGET_FILE_EXTENSIONS"), this.defaultExt);
		this.client = this.propertiesCache.getProperty("CLIENT_NAME");
		this.successfulUploadList = new ArrayList<String>();
		this.failedUploadList = new ArrayList<String>();
		this.backupPath = this.ensureBackupDirectory();
		
	}

	/**
	 * This method download the FTP file from FTP server
	 * 
	 * @throws FTPDownloaderException
	 *
	 * @since 10-OCT-2019
	 * @see FTPClient
	 * @see BufferedOutputStream
	 */
	public Boolean uploadEachFile(File file) throws FTPUploaderException {
		LOGGER.debug("uploadFile method is called .....");
		boolean successOrFail = Boolean.FALSE;
		BufferedInputStream bufferedInputStream = null;
		OutputStream outputStream = null;
		try {
			bufferedInputStream = new BufferedInputStream(new FileInputStream(file));
			outputStream = this.ftp.storeFileStream(file.getName());

			int available = bufferedInputStream.available();
			LOGGER.info("Available bytes to read : " + available);
			
			int bufferSize = Integer.parseInt(ApplicationPropertiesCacheHolder.getInstance().getProperty("UPLOAD_BUFFER_SIZE"));
			
			LOGGER.info("Upload Buffer size configured in application.properties: "+bufferSize);

			byte[] buffer = new byte[bufferSize];
			int bytesRead = 0;
			
			while ((bytesRead = bufferedInputStream.read(buffer)) != -1) {
				outputStream.write(buffer, 0, bytesRead);				
			}
			
			/*successOrFail = this.ftp.completePendingCommand();
			System.out.println("Debug : 1 ");
			if (successOrFail) {
				System.out.println("Debug : 2 ");
				LOGGER.info("File [" + file.toString() + "] has been uploaded successfully....");
			}*/
			//System.out.println("Debug : 3 ");
		} catch (IOException ex) {
			LOGGER.error("Error: " + ex.getMessage());
			throw new FTPUploaderException(ex.getMessage());
		} catch (Exception e) {
			LOGGER.error("Error: " + e.getMessage());
			throw new FTPUploaderException(e.getMessage());
		} finally {
			try {
				if (bufferedInputStream != null){
					bufferedInputStream.close();
					LOGGER.debug("Input stream closed ....");
				}
					
				if (outputStream != null){
					outputStream.close();
					LOGGER.debug("Output stream closed ....");
				}
				
			} catch (IOException e) {
				LOGGER.error(e);
			}
		}

		LOGGER.info("uploadFile method is executed .....");

		return successOrFail;
	}
	
	/**
	 * Utility to create an arbitrary directory hierarchy on the remote ftp
	 * server
	 * @since 12-10-2019
	 * @param client
	 * @param dirTree
	 *            the directory tree only delimited with / chars. No file name!
	 * @throws Exception
	 */
	public boolean makeOrChangeToClientDirectory(String clientName) throws IOException {
	 
	  boolean dirExists = true;
	  
	  if (dirExists) {
	    dirExists = this.ftp.changeWorkingDirectory(clientName);
	    showServerReply(this.ftp);
	  }
	  if (!dirExists) {
		if (!this.ftp.makeDirectory(clientName)) {
		  throw new IOException("Unable to create remote directory '" + clientName + "'.  error='" + this.ftp.getReplyString() + "'");
		}
		if (!this.ftp.changeWorkingDirectory(clientName)) {
		  throw new IOException("Unable to change into newly created remote directory '" + clientName + "'.  error='" + this.ftp.getReplyString() + "'");
		}
	  }
	 return dirExists;
	 }
	
	/**
     * Change the current working directory using current FTP session.
     *
     * @param pathname  The new current working directory.
     * @return True if successfully completed, false if not.
     * @throws IOException
    
     * @throws IOException  If an I/O error occurs while either sending a
     *      command to the server or receiving a reply from the server.
     */
	private boolean changeWorkingDirectory(String pathname) throws IOException{
		// Changes working directory
        boolean status = this.ftp.changeWorkingDirectory(pathname);
        showServerReply(this.ftp);

        if (status) {
            LOGGER.info("Successfully changed working directory.");
        } else {
        	LOGGER.info("Failed to change working directory. See server's reply.");
        }
        
        return status;
	}

	/**
	 * This method returns the target files to download depending on the allowed
	 * file extensions mentioned in application.properties with a key as
	 * TARGET_FILE_EXTENSIONS. Always the txt file(s) are by default eligible to
	 * be selected
	 * 
	 * @return <code>List<File></code>
	 * @throws <code>FTPFileListingException</code>
	 * @since 11-OCT-2019
	 * @see com.client.adapter.utility.ApplicationUploadDownloadUtility for
	 *      findExtension(String fileName)
	 * @see Arrays
	 * @see <code>FTPFileListingException</code>
	 * @see getAllowableFileExts() method
	 */
	public List<Path> getFileListByExtension(String inputDirPath) throws FTPFileListingException {
		LOGGER.debug("getFileListByExtension() method started executing ...");
		List<Path> files = null;
		try {

			files = Files.walk(Paths.get(inputDirPath)).filter(Files::isRegularFile)
					.filter((s) -> getAllowableFileExts().contains(
							ApplicationUploadDownloadUtility.findExtension(s.getFileName().toString()).orElse(""))).collect(Collectors.toList());

			//LOGGER.info("Size : " + files.count());
		} catch (Exception e) {
			LOGGER.error(e);
			throw new FTPFileListingException("Exception occurred during listing FTP server files");
		}
		LOGGER.debug("getFileListByExtension() method completed executing ...");
		return files;
	}

	/**
	 * Closes the connection to the FTP server and restores connection
	 * parameters to the default values.
	 * 
	 * Logout of the FTP server by sending the QUIT command.
	 *
	 * @return True if successfully completed, false if not.
	 *
	 * @throws IOException
	 *             If an error occurs while disconnecting.
	 */
	public boolean disconnect() {
		boolean isDisconnected = Boolean.FALSE;
		if (this.ftp.isConnected()) {
			try {
				isDisconnected = this.ftp.logout();
				LOGGER.info(isDisconnected == true ? "The FTP connection is disconnected successfully ..." : "");
				this.ftp.disconnect();
			} catch (IOException f) {
				LOGGER.error("disconnection attempt failed", f);
			}
		}
		return isDisconnected;
	}

	/**
	 * 
	 * @param files
	 */
	public void printAllFiles(Stream<Path> files) {
		LOGGER.debug("Execution start : Printing all file to be uploaded ");
		files.forEach(p -> LOGGER.info(p.toString()));
		LOGGER.debug("Execution ends : Printing all file to be uploaded ");
	}
	
	/**
	 * 
	 * @param paths
	 */
	public void uploadFiles(List<Path> paths) {
		
		LOGGER.debug("uploadFiles method execution started ......");		
		LOGGER.info("File upload started .....");
		final boolean uploadStat = Boolean.FALSE;
		if(paths!=null)
			this.totalFileCount = (int) paths.size();
		LOGGER.info("Total files to be uploaded for Client[ "+this.getClient()+" ] ::  "+this.totalFileCount);
			paths.forEach(path -> {
				File file = null;
				try {
					file = path.toFile();					
					if(file!= null){						
						this.uploadEachFile(file);
						this.getSuccessfulUploadList().add(file.getAbsolutePath());
						this.backupFile(file);						
					}
						
			    } catch (FTPUploaderException e) {		
			    	this.getFailedUploadList().add(file.getAbsolutePath());
					LOGGER.error("File [" + file.getAbsolutePath() + " ] upload failed ...");					
					LOGGER.error(e);
					
				} catch (BackupFileException e) {
					LOGGER.error("File backup has failed . "+e.getMessage());
					LOGGER.error(e);
					
				}catch (Exception e) {
					LOGGER.error(e);
				} 
			});
			
		this.showUploadStatictics();
		
		LOGGER.debug("uploadFiles completed .....");
		
		}	
	/**
	 * Backs up the last uploaded file from source directory to 
	 * backup directory which has been mentioned in application.properties file with a key as "BACKUP_DIRECTORY_NAME"
	 * 
	 * @since 13-OCT-2019
	 * @param fileToBackup
	 * @return {@link Boolean}
	 * @throws BackupFileException
	 * @see {@link ApplicationUploadDownloadUtility}
	 * @See {@link Paths}
	 */
	private boolean backupFile(File fileToBackup ) throws  BackupFileException {
		boolean renameStatus = Boolean.FALSE;
		if(fileToBackup!= null){
			try {
				Path destination = Paths.get(this.backupPath.toAbsolutePath().toString(), fileToBackup.getName());
				LOGGER.info("Destination: "+destination.toAbsolutePath().toString());
				ApplicationUploadDownloadUtility.moveFile(fileToBackup, destination.toFile());
				String postUploadExtn = getPropertiesCache().getProperty("POST_UPLOAD_EXTENSION");
				renameStatus = ApplicationUploadDownloadUtility.renameFile(this.backupPath.toFile(), fileToBackup.getName(), postUploadExtn);
			} catch (Exception e) {				
				throw new BackupFileException("Backup failed for "+fileToBackup.getAbsolutePath(),e);
			}
		}
		
		return renameStatus;
		
	}
	/**
	 * 
	 * @param ftpClient The FTP client object 
	 */
	
	private void showServerReply(FTPClient ftpClient) {
        String[] replies = ftpClient.getReplyStrings();
        if (replies != null && replies.length > 0) {
            for (String aReply : replies) {
                LOGGER.info("SERVER: " + aReply);
            }
        }
    }
	
	/**
	 * 
	 */			
	private void showUploadStatictics(){
		LOGGER.info("=================== File Upload statistics for Client : "+getClient()+"==================");
		LOGGER.info("Total upload File(s) in queue count : "+this.getTotalFileCount());
		LOGGER.info("Total successful count : "+this.getSuccessfulUploadList().size());
		LOGGER.info("Total failed attempt count : "+this.getFailedUploadList().size());
		LOGGER.info("=========================================================================================");
		
	}
	
	/**
	 * 
	 * @return
	 */
	public Path getInputDirectoryPath(){		
		String userHome = ApplicationUploadDownloadUtility.getUserHomeDirectory();
		Path path = Paths.get(userHome, getClient() , getOperation());		
		return path;
	}
	/**
	 * 
	 */
	private Path ensureBackupDirectory(){
		
		String userHome = ApplicationUploadDownloadUtility.getUserHomeDirectory();
		Path path = Paths.get(userHome, this.getClient(), propertiesCache.getProperty("BACKUP_DIRECTORY_NAME"));
		Path backUppath = ApplicationUploadDownloadUtility.ensureDirectories(path.toAbsolutePath().toString());
		LOGGER.info("Backup Directory created at [ "+backUppath.toAbsolutePath().toString()+" ] ...");
		
		return backUppath;
	}
	

	public FTPClient getFtp() {
		return ftp;
	}

	public ApplicationPropertiesCacheHolder getPropertiesCache() {
		return propertiesCache;
	}

	public Set<String> getAllowableFileExts() {
		return allowableFileExts;
	}	


	public String getDefaultExt() {
		return defaultExt;
	}

	public String getClient() {
		return client;
	}

	public List<String> getSuccessfulUploadList() {
		return successfulUploadList;
	}

	public void setSuccessfulUploadList(List<String> successfulUploadList) {
		this.successfulUploadList = successfulUploadList;
	}

	public List<String> getFailedUploadList() {
		return failedUploadList;
	}

	public void setFailedUploadList(List<String> failedUploadList) {
		this.failedUploadList = failedUploadList;
	}	

	public int getTotalFileCount() {
		return totalFileCount;
	}

	public void setTotalFileCount(int totalFileCount) {
		this.totalFileCount = totalFileCount;
	}
	
	public String getOperation(){
		return "UPLOAD";
	}

	public static void main(String[] args) throws FTPFileListingException {
		
		 /*String server = "ftp.dlptest.com"; 
		 String user ="dlpuser@dlptest.com";
		 String pass = "fLDScD4Ynth0p4OJ6bW6qCxjh";*/
		 		 
		/*String server = "speedtest4.tele2.net";
		// int port = 21;
		String user = "anonymous";
		String pass = "anonymous";*/

		 
		 String server = "demo.wftpserver.com"; 
		 String user ="demo-user";
		 String pass = "demo-user";		 		 

		FTPUploader uploader = null;
		try {
			
			uploader = new FTPUploader(server, user, pass);
			uploader.makeOrChangeToClientDirectory("/upload");
			Path path = uploader.getInputDirectoryPath();
			
			List<Path> files = uploader.getFileListByExtension(path.toAbsolutePath().toString());
			uploader.uploadFiles(files);
			uploader.disconnect();
			
		} catch (Exception e) {
			e.printStackTrace();
		}		
	}
	
	public static void processUpload(FTPUploader uploader , String server, String user , String pass) throws FTPUploaderException{
		try {
			
			uploader = new FTPUploader(server, user, pass);
			uploader.makeOrChangeToClientDirectory("/upload");
			Path path = uploader.getInputDirectoryPath();
			
			List<Path> files = uploader.getFileListByExtension(path.toAbsolutePath().toString());
			uploader.uploadFiles(files);
			uploader.disconnect();
			
		} catch (Exception e) {
			throw new FTPUploaderException(e.getMessage());
		}
	}
}
