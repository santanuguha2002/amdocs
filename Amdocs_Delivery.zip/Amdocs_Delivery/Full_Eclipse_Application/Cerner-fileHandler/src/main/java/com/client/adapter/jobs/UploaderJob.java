package com.client.adapter.jobs;

import java.nio.file.Path;
import java.util.Date;
import java.util.List;

import org.apache.log4j.Logger;
import org.quartz.DisallowConcurrentExecution;
import org.quartz.ExecuteInJTATransaction;
import org.quartz.Job;
import org.quartz.JobBuilder;
import org.quartz.JobDataMap;
import org.quartz.JobDetail;
import org.quartz.JobExecutionContext;
import org.quartz.JobExecutionException;
import org.quartz.PersistJobDataAfterExecution;
import org.quartz.Scheduler;
import org.quartz.Trigger;

import com.client.adapter.configuration.ApplicationPropertiesCacheHolder;
import com.client.adapter.exception.PropertiesLoadException;
import com.client.adapter.uploader.FTPUploader;
import com.client.adapter.utility.Constants;

/**
 * The class {@link DownloaderJob} to represent a 'job' to be
 * performed for uploading files to Server using FTP.
 * 
 * @author santanu
 * @since 10-OCT-2019
 * 
 * @throws JobExecutionException
     if there is an exception while executing the job.
     @see JobDetail
 * @see JobBuilder
 * @see ExecuteInJTATransaction
 * @see DisallowConcurrentExecution
 * @see PersistJobDataAfterExecution
 * @see Trigger
 * @see Scheduler
 */
@DisallowConcurrentExecution
public class UploaderJob implements Job , Cloneable{	
	
	private static final Logger LOGGER = Logger.getLogger(UploaderJob.class.getName());
	private ApplicationPropertiesCacheHolder cacheHolder = null;

	public UploaderJob() throws PropertiesLoadException {
		super();	
		this.cacheHolder = ApplicationPropertiesCacheHolder.getInstance();
	}

	@Override
	public void execute(JobExecutionContext context) throws JobExecutionException {
		
		LOGGER.info("######## Uploader Job has been started executing on " + new Date());		
		JobDataMap dataMap = context.getJobDetail().getJobDataMap();
		
		final String host = (String) dataMap.get(Constants.HOST);
		final String user = (String) dataMap.get(Constants.USER);
		final String pass = (String) dataMap.get(Constants.PASS);	
		
		final String targetDirectory = (String) dataMap.get(Constants.TARGET_UPLOAD_DIRECTORY);
		
		String clientName = getCacheHolder().getProperty("CLIENT_NAME");
		
		FTPUploader uploader = null;
		try {
			
			uploader = new FTPUploader(host , user , pass );
			if(targetDirectory!=null && !"".equals(targetDirectory))
				uploader.makeOrChangeToClientDirectory(targetDirectory);
			
			Path path = uploader.getInputDirectoryPath();
			
			List<Path> files = uploader.getFileListByExtension(path.toAbsolutePath().toString());
			uploader.uploadFiles(files);
			uploader.disconnect();
			
		} catch (Exception e) {			
			LOGGER.error(e);
		}
		
		LOGGER.info("Uploader Job has completed executing on " + new Date());
	}
	
	@Override
	protected Object clone() throws CloneNotSupportedException {		
		return new CloneNotSupportedException("Cloning of this JOb is not permitted ...");
	}

	public ApplicationPropertiesCacheHolder getCacheHolder() {
		return cacheHolder;
	}	

}
