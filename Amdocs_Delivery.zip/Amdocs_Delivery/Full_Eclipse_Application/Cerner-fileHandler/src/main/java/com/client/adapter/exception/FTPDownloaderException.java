package com.client.adapter.exception;

public class FTPDownloaderException extends Exception {

	public FTPDownloaderException(String message) {
		super(message);		
	}

	public FTPDownloaderException(Throwable cause) {
		super(cause);		
	}

	public FTPDownloaderException(String message, Throwable cause) {
		super(message, cause);		
	}
}
