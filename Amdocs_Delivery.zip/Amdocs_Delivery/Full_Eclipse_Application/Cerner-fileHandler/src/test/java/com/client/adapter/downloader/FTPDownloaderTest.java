package com.client.adapter.downloader;

import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;
import static org.junit.Assert.fail;

import java.io.IOException;
import java.util.List;

import org.apache.commons.net.ftp.FTPFile;
import org.junit.After;
import org.junit.Before;
import org.junit.Ignore;
import org.junit.Test;

import com.client.adapter.exception.FTPDownloaderException;
import com.client.adapter.exception.FTPFileListingException;

public class FTPDownloaderTest { 
	
	private FTPDownloader downLoader = null;
	private String host = null; 
	private String user = null;
	private String pwd = null;	 
	private List<FTPFile> ftpFilelist = null;

	@Before
	public void setUp() throws Exception {		
		 host = "demo.wftpserver.com"; 
		 user ="demo-user";
		 pwd = "demo-user";	
		 downLoader = new FTPDownloader(host, user, pwd);
		 //mvn clean assembly:single
		 //mvn site
		 //mvn clean install test surefire-report:report
	}

	@Test
	public void testFTPDownloader() {		
		assertNotNull(downLoader);
	}

	@Test(expected=FTPDownloaderException.class)
	public void testDownloadFile() throws FTPDownloaderException {
		
		downLoader.downloadFile(null);
		
		assertNotNull(downLoader);
	}

	@Test
	public void testGetFileListByExtension() {
		try {
			this.ftpFilelist = downLoader.getFileListByExtension();
		} catch (FTPFileListingException e) {			
			e.printStackTrace();
		}		
		assertTrue( this.ftpFilelist.size() >= 0 );
		
	}
	
	@Test
	public void testChangeWorkingDirectory() {
		boolean result = false;
		try {
			result = downLoader.changeWorkingDirectory("/download");
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}		
		assertTrue(result);
	}
	
	@Test
	@Ignore
	public void testDownloadAllFiles() {
		fail("Not yet implemented");
	}

	@Test
	public void testDisconnect() {
		boolean isDisconnected  = downLoader.disconnect();
		assertTrue(isDisconnected);
	}

	@After
	public void tearDown() throws Exception {
		
		this.downLoader = null;
		
	}
}
