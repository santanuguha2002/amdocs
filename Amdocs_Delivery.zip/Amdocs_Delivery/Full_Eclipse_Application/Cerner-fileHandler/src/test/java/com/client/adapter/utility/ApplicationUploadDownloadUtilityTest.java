package com.client.adapter.utility;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

import java.io.File;
import java.io.IOException;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Optional;
import java.util.Properties;
import java.util.Set;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

public class ApplicationUploadDownloadUtilityTest {
	
	private ApplicationUploadDownloadUtility utility = null;
	String home = null;

	@Before
	public void setUp() throws Exception {
		utility = new ApplicationUploadDownloadUtility();
		home = ApplicationUploadDownloadUtility.getUserHomeDirectory();	
	}

	@After
	public void tearDown() throws Exception {
		utility = null;
		home = null;
	}

	@Test
	public void testGetUserHomeDirectory() {
		 		
		assertNotNull(home);
	}

	@Test
	public void testEnsureDirectories() {
		String home = ApplicationUploadDownloadUtility.getUserHomeDirectory();	
		Path path = ApplicationUploadDownloadUtility.ensureDirectories(home);
		
		assertNotNull(path);
	}

	@Test
	public void testCopyProperties() {
		
		Properties p1 = new Properties();
		p1.put("Santanu", "Testing");
		Properties p2 = new Properties();
		
		ApplicationUploadDownloadUtility.copyProperties(p2, p1);
		
		Object o = p2.get("Santanu");
		assertNotNull(o);
		
	}

	@Test
	public void testGetAllowableFileExtensionList() {		
		String extensions = "txt|zip|ser";
		Set<String> set = ApplicationUploadDownloadUtility.getAllowableFileExtensionList(extensions, "pdf");
		
		int setSize = set.size();		
		assertEquals(setSize , 4);		
		
	}

	@Test
	public void testFindExtension() {
		
		String fileName = "Santanu.zip";
		Optional<String> result = ApplicationUploadDownloadUtility.findExtension(fileName);
		
		assertEquals("zip" , result.orElse(""));
	}

	@Test
	public void testRenameFileExtension() {
		
		String what = ApplicationUploadDownloadUtility.renameFileExtension("Santanu.txt", "pdf");
		assertEquals("Santanu.pdf" , what);
	}
	

	@Test
	public void testMoveFile() throws IOException {		
		
		String home = ApplicationUploadDownloadUtility.getUserHomeDirectory();
		System.out.println("Home : "+home);
		File newFile = null;
		
		File file = new File(home+System.getProperty("file.separator")+"file.txt");
		boolean result = file.createNewFile();
		System.out.println("result : "+result);
        try {
			if(result){
				System.out.println("Location of File : "+file.getAbsolutePath());
				 
				newFile = new File(Paths.get(ApplicationUploadDownloadUtility.getUserTempDirectory(), file.getName()).toAbsolutePath().toString());
				ApplicationUploadDownloadUtility.moveFile(file, newFile);
				System.out.println("Moved ...");
			}
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
        
        boolean exists = newFile.exists();
        assertEquals(true , exists);
        
	}
	
	

}
