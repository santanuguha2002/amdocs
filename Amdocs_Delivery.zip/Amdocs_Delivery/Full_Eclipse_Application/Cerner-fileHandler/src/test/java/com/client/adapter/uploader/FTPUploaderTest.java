package com.client.adapter.uploader;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;
import static org.junit.Assert.fail;

import java.io.IOException;
import java.nio.file.Path;
import java.util.List;

import org.junit.After;
import org.junit.Before;
import org.junit.Ignore;
import org.junit.Test;

import com.client.adapter.configuration.ApplicationPropertiesCacheHolder;
import com.client.adapter.exception.FTPFileListingException;

public class FTPUploaderTest {
	
	private FTPUploader uploader = null;
	private String host = null; 
	private String user = null;
	private String pwd = null;	 
	List<Path> files  = null;
	ApplicationPropertiesCacheHolder cache = null;

	@Before
	public void setUp() throws Exception {
		
		 host = "demo.wftpserver.com"; 
		 user ="demo-user";
		 pwd = "demo-user";	
		 cache = ApplicationPropertiesCacheHolder.getInstance();
		 uploader = new FTPUploader(host, user, pwd);		 
	}

	@Test
	public void testFTPUploader() {
		assertNotNull(uploader);
	}

	@Test
	@Ignore
	public void testUploadEachFile() {
		fail("Not yet implemented");
	}

	@Test
	public void testMakeOrChangeToClientDirectory() {
		boolean actualResult = false;
		try {
			actualResult = uploader.makeOrChangeToClientDirectory("/upload");
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}		
		assertEquals(true , actualResult);
	}

	@Test
	public void testGetFileListByExtension() {
		
		Path path = uploader.getInputDirectoryPath();		
		try {
			this.files = uploader.getFileListByExtension(path.toAbsolutePath().toString());
		} catch (FTPFileListingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		assertTrue( files.size() >= 0 );
	}

	@Test
	public void testDisconnect() {
		boolean result = uploader.disconnect();
		assertEquals(true , result);
	}
	
	@After
	public void tearDown() throws Exception {
		uploader = null;
		cache = null;
	}

}
