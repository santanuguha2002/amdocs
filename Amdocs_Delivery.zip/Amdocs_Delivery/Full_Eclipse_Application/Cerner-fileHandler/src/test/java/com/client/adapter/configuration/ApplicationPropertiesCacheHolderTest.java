package com.client.adapter.configuration;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import com.client.adapter.exception.PropertiesLoadException;

public class ApplicationPropertiesCacheHolderTest {
	
	ApplicationPropertiesCacheHolder cache = null;

	@Before
	public void setUp() throws Exception {
		cache = ApplicationPropertiesCacheHolder.getInstance();
	}

	@After
	public void tearDown() throws Exception {
		cache = null;
	}

	@Test
	
	public void testGetInstance() throws PropertiesLoadException {		
		assertNotNull(cache);
	}

	@Test()	
	public void testGetProperty() {
		String client = cache.getProperty("CLIENT_NAME");
		assertNotNull(client);
	}

	@Test	
	public void testContainsKey() {
		boolean isFound = cache.containsKey("CLIENT_NAME");
		assertTrue(isFound);
	}

}
